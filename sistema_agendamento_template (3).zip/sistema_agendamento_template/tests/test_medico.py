import pytest
from src.medico import Medico

def test_adicionar_e_remover_horario():
    m = Medico("Dr. Silva", "Cardiologia")
    m.adicionar_horario("2025-10-20 10:00")
    assert m.disponivel("2025-10-20 10:00") is True
    m.remover_horario("2025-10-20 10:00")
    assert m.disponivel("2025-10-20 10:00") is False

def test_adicionar_horario_existente():
    m = Medico("Dr. A", "Geral")
    m.adicionar_horario("2025-10-20 11:00")
    with pytest.raises(ValueError):
        m.adicionar_horario("2025-10-20 11:00")

def test_remover_horario_inexistente_erro():
    m = Medico("Dr. B", "Orto")
    with pytest.raises(ValueError):
        m.remover_horario("2025-10-20 12:00")

def test_agenda_inicial_sem_duplicatas():
    m = Medico("Dr. Pedro", "Clínico", ["09:00", "09:00", "10:00"])
    assert m.agenda == ["09:00", "10:00"]


def test_disponibilidade_retorna_false_para_horario_inexistente():
    m = Medico("Dr. Joao", "Geral", ["08:00"])
    assert not m.disponivel("09:00")