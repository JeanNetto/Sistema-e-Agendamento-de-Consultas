import pytest
from src.paciente import Paciente
from src.medico import Medico
from src.agendamento import Agendamento


def test_cancelar_agendamento_confirmado():
    p = Paciente("José", "11122233344", ativo=True)
    m = Medico("Dr. X", "Cardiologia", agenda=["2025-10-20 09:00"])
    ag = Agendamento(p, m, "2025-10-20 09:00")
    ag.confirmar()
    assert not m.disponivel("2025-10-20 09:00")
    ag.cancelar()
    assert ag.status == "CANCELADO"
    assert m.disponivel("2025-10-20 09:00")


def test_fluxo_confirmar_realizar():
    p= Paciente("Carlos", "11122233344", ativo=True)
    m = Medico("Dra. Luiza", "Dermatologia", agenda=["2025-10-20 10:00"])
    ag = Agendamento(p, m, "2025-10-20 10:00")
    ag.confirmar()
    assert ag.status == "CONFIRMADO"
    assert not m.disponivel("2025-10-20 10:00")
    ag.realizar()
    assert ag.status == "REALIZADO"


def test_confirmar_agendamento_com_paciente_inativo():
    p = Paciente("Lia", "11122233344", ativo=False)
    m = Medico("Dr. Mario", "Geral", agenda=["2025-10-20 09:00"])
    ag = Agendamento(p, m, "2025-10-20 09:00")
    with pytest.raises(RuntimeError):
        ag.confirmar()


def test_realizar_sem_confirmar():
    p = Paciente("Lia", "11122233344", ativo=True)
    m = Medico("Dr. Mario", "Geral", agenda=["2025-10-20 09:00"])
    ag = Agendamento(p, m, "2025-10-20 09:00")
    with pytest.raises(RuntimeError):
        ag.realizar()


def test_confirmar_duas_vezes():
    p = Paciente("Julia", "12345678901")
    m = Medico("Dr. Renato", "Clínico", ["10:00"])
    ag = Agendamento(p, m, "10:00")
    ag.confirmar()
    with pytest.raises(RuntimeError):
        ag.confirmar()

def test_realizar_fluxo_completo_depois_de_cancelar_novo():
    p = Paciente("Silvia", "44455566677", ativo=True)
    m = Medico("Dr. André", "Ortopedia", agenda=["2025-10-26 08:00"])
    ag = Agendamento(p, m, "2025-10-26 08:00")
    ag.cancelar()
    assert ag.status == "CANCELADO"
    # recriando novo agendamento no mesmo horário agora disponível
    novo = Agendamento(p, m, "2025-10-26 08:00")
    novo.confirmar()
    novo.realizar()
    assert novo.status == "REALIZADO"

def test_status_inicial_agendamento():
    p = Paciente("Nina", "22233344455", ativo=True)
    m = Medico("Dr. Jorge", "Clínico", agenda=["2025-10-25 10:00"])
    ag = Agendamento(p, m, "2025-10-25 10:00")
    assert ag.status == "CRIADO"

def test_confirmar_horario_indisponivel():
    p = Paciente("Igor", "12312312312", ativo=True)
    m = Medico("Dr. Lucas", "Geral", agenda=["2025-10-24 09:00"])
    ag = Agendamento(p, m, "2025-10-25 09:00")  # horário não está na agenda
    with pytest.raises(RuntimeError):
        ag.confirmar()