import pytest
from src.paciente import Paciente

def test_cpf_valido():
    p = Paciente("João", "12345678901")
    assert p.nome == "João"
    assert p.cpf == "12345678901"

def test_cpf_invalido_tamanho():
    with pytest.raises(ValueError):
        Paciente("Maria", "123")

def test_cpf_invalido_nao_numerico():
    with pytest.raises(ValueError):
        Paciente("Ana", "abcdefghijk")

def test_paciente_inativo_nao_pode_agendar():
    p = Paciente("Carlos", "12345678901", ativo=False)
    assert not p.ativo

