from typing import List

class Medico:
    def __init__(self, nome: str, especialidade: str, agenda: List[str] = None):
        self.nome = nome
        self.especialidade = especialidade
        # Garante lista sem duplicados
        self.agenda = list(dict.fromkeys(agenda)) if agenda else []

    def adicionar_horario(self, horario: str):
        # Permite adicionar apenas se ainda não existir
        if horario in self.agenda:
            raise ValueError("Horário já existe na agenda")
        self.agenda.append(horario)

    def remover_horario(self, horario: str):
        # Remove apenas se existir
        if horario not in self.agenda:
            raise ValueError("Horário inexistente")
        self.agenda.remove(horario)

    def disponivel(self, horario: str) -> bool:
        return horario in self.agenda