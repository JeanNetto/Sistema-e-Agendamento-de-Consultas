from enum import Enum

class Status(Enum):
    CRIADO = "CRIADO"
    CONFIRMADO = "CONFIRMADO"
    REALIZADO = "REALIZADO"
    CANCELADO = "CANCELADO"


class Agendamento:
    def __init__(self, paciente, medico, horario: str):
        self.paciente = paciente
        self.medico = medico
        self.horario = horario
        self.status = Status.CRIADO.value

    def confirmar(self):
        if self.status != Status.CRIADO.value:
            raise RuntimeError("Só é possível confirmar um agendamento com status CRIADO")
        if not self.paciente.ativo:
            raise RuntimeError("Paciente inativo não pode realizar agendamento")
        if not self.medico.disponivel(self.horario):
            raise RuntimeError("Médico não disponível no horário solicitado")
        self.medico.remover_horario(self.horario)
        self.status = Status.CONFIRMADO.value

    def realizar(self):
        if self.status != Status.CONFIRMADO.value:
            raise RuntimeError("Só é possível realizar um agendamento confirmado")
        self.status = Status.REALIZADO.value

    def cancelar(self):
        # Cancela o agendamento e devolve o horário somente se ele não estiver na agenda
        if self.status == Status.CONFIRMADO.value and not self.medico.disponivel(self.horario):
            self.medico.agenda.append(self.horario)
        self.status = Status.CANCELADO.value
