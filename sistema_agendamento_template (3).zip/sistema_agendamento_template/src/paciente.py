class Paciente:
    def __init__(self, nome: str, cpf: str, ativo: bool = True):
        self.nome = nome
        self.cpf = cpf
        self.ativo = ativo
        self._validar_cpf()

    def _validar_cpf(self):
        if not isinstance(self.cpf, str):
            raise ValueError("CPF deve ser uma string com 11 dígitos numéricos")
        if len(self.cpf) != 11 or not self.cpf.isdigit():
            raise ValueError("CPF inválido: deve conter exatamente 11 dígitos numéricos")
        
